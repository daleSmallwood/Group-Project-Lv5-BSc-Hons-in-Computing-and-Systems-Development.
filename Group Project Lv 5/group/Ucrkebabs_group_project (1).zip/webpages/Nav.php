<div class="NavBar">
  <nav>
    <li><a href="UCRkebabsHome.php">Home</a></li>
    <li><a href="UCRkebabsMenu.php">Menu</a></li>
    <li><a href="Contact.php">Contact us</a></li>
    <li><a href="About.php">About us</a></li>
  </nav>
</div>
