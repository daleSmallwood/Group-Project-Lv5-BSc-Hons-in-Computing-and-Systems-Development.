<?php
define("Username","root");
define("Password", "");
define("Database","ucrkebabsaccounts");
define("Host","localhost");
?>
